﻿using System;
using System.Collections.Generic;
using System.IO;
using Tut_2._2.Helpers;
using Tut_2._2.Models;
namespace Tut_2._2
{
    class Program
    {
        
        static void Main(string[] args)
        {

             
            using StreamWriter streamWriter = new StreamWriter(@"log.txt");
            try
            {
                string path = args.Length > 0 ? args[0] : "dane.csv";
                string dataFormat = args.Length > 0 ? args[2] : "json";
                string destinationPath = args.Length > 0 ? args[1] : $"result.{dataFormat}";
                FileInfo fi = new FileInfo(path);
                HashSet<Student> students = FileParser.ParseFileFromCsv(fi);

                activeStudies ac = new activeStudies() { studentsList = students, };
                University uni = new University() { students = students, };
                
                string author = "Mehlika_Bilgicli_20321";
                DateTime time = DateTime.Now;

                

                string jsonString = Serializer.SerializeToJon(students);
                File.WriteAllText(destinationPath, jsonString);//we want to write to destination part in json content
            }
            catch (ArgumentException)
            {
                streamWriter.WriteLine("The path is incorrect");
            }
            catch (FileNotFoundException)
            {
                streamWriter.WriteLine("File does not exist");
            }
            finally
            {
                streamWriter.Close();
            }
        }
    }
}