﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Tut_2._2.Helpers
{
    class Subject
    {
        public string Name { get; set; }

        public int NumberOfStudents { get; set; }
    }
}
