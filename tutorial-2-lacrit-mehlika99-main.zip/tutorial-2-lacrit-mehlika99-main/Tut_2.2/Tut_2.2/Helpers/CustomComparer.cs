﻿using System;
using System.Collections.Generic;
using Tut_2._2.Models;
namespace Tut_2._2.Helpers
{
    public class CustomComparer : IEqualityComparer<Student>
    {
        public bool Equals(Student x, Student y)
        {
           
            return StringComparer
                .InvariantCultureIgnoreCase
                .Equals($"{x.IndexNumber} {x.Email} {x.FirstName} {x.LastName}",
                $"{y.IndexNumber} {y.Email} {y.FirstName} {y.LastName}");
        }
        public int GetHashCode(Student obj)
        {
            return StringComparer
                .CurrentCultureIgnoreCase
                .GetHashCode($"{obj.IndexNumber} {obj.Email} {obj.FirstName} {obj.LastName}");
        }
    }
}