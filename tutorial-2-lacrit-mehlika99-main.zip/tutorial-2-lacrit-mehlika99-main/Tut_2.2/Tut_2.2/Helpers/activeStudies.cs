﻿using System.Collections.Generic;

using Tut_2._2.Models;

namespace Tut_2._2.Helpers
{
    internal class activeStudies
    {
        public List<string> activeSubjects = new List<string>();

        public HashSet<Student> studentsList = new HashSet<Student>(new CustomComparer());

       

       

    }
}
