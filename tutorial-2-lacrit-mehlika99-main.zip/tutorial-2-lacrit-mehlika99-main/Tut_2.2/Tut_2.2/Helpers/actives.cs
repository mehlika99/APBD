﻿
using System.Text.Json.Serialization;

namespace Tut_2._2.Helpers
{
    class actives
    {
        [JsonPropertyName("name")]
        string name { get; set; }

        [JsonPropertyName("numberOfStudents")]
        int numberOfStudents  { get; set; }

       




    }
}
