﻿using System;
using System.Text.Json.Serialization;

namespace Tut_2._2.Helpers
{
    public class Studies
    {
        [JsonPropertyName("name")]
        public string name { get; set; }
        [JsonPropertyName("mode")]
        public string mode { get; set; }

        public Studies() { }

        public string GetName()
        {
            if (string.IsNullOrEmpty(this.name))
            {
                return "Name is empty";
            }
            else
            {
                return this.name;
            }
        }

        public void SetName(string name)
        {
            if (string.IsNullOrEmpty(name))
            {
                throw new Exception("Name cannot be empty");
            }
            this.name = name;
        }
    
        public string GetMode()
        {
            if (string.IsNullOrEmpty(this.mode))
            {
                return "No mod find";
            }
            else
            {
                return this.mode;
            }
        }

        public void SetMode(string mode)
        {
            if (string.IsNullOrEmpty(mode))
            {
                throw new Exception("Mode cannot be empty");
            }
            this.mode = mode;
        }



    }
}