﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.Encodings.Web;
using System.Text.Json;
using System.Text.Unicode;
using Tut_2._2.Models;
namespace Tut_2._2.Helpers
{
    public class Serializer
    {
        public static string SerializeToJon(HashSet<Student> students)
        {
            var options = new JsonSerializerOptions//for polish letters
            {
                Encoder = JavaScriptEncoder.Create(UnicodeRanges.All),
                WriteIndented = true
            };
            return JsonSerializer.Serialize(students, options);
        }
    }
}