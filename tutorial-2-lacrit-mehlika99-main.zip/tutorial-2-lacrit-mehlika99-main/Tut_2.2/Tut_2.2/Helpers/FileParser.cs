﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using Tut_2._2.Models;
namespace Tut_2._2.Helpers
{
    public static class FileParser
    {
        public static HashSet<Student> ParseFileFromCsv(FileInfo file)
        {
            
            HashSet<Student> students = new HashSet<Student>(new CustomComparer());

            //declaration of student gelicek
            using (
                StreamReader stream = new StreamReader(file.OpenRead()))
            {
                string line = null;
                while ((line = stream.ReadLine()) != null)
                {
                    string[] student = line.Split(',');//where we get student

                    if (student.GetLength(0) == 9)
                    {

                        Boolean okay = true;
                        //if all columns are full
                        foreach (string s in student) if (string.IsNullOrWhiteSpace(s)) okay = false;
                        if (okay == true)
                        {

                            var st = new Student//where i want to translete
                            {
                                IndexNumber = student[4],
                                FirstName = student[0],
                                LastName = student[1],
                                BirthDate = DateTime.Parse(student[5]),
                                Email = student[6],
                                MothersName = student[7],
                                FathersName = student[8],
                                Studies = new Studies
                                {
                                    name = student[2],
                                    mode = student[3]
                                }

                            };
                            students.Add(st);

                             /*//if no duplication
                             if (students.Contains(st))
                             {


                                 streamWrite.WriteLine($"Student with the firstName: {st.FirstName} was not added due to duplicate");
                             }
                             else students.Add(st);
                         }
                         else
                         {  //empty error into log.txt
                             streamWrite.WriteLine("columns empty");
                         }
                     }
                     else
                     {  //less then 9 columns error into log.txt
                         streamWrite.WriteLine("Not 9 columns.");
                     }*/

                        }
                    }
            
                }

            }

            
            return students;

        }
    }
}

    

    

