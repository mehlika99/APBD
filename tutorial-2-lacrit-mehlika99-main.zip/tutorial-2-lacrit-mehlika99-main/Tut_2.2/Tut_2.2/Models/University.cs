﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.Json.Serialization;
using Tut_2._2.Helpers;

namespace Tut_2._2.Models
{
    public class University
    {
        

        [JsonPropertyName("createdAt")]
        public string createdAt { get; set; }

        [JsonPropertyName("author")]
        public string author { get; set; }

        
        public HashSet<Student> students { get; set; }

        

        [JsonPropertyName("activeSubjects")]
        public HashSet<string> activesub { get; set; }

        






    }
}
