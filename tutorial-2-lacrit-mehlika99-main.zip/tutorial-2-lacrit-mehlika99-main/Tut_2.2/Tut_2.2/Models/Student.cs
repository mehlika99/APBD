﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.Json.Serialization;
using Tut_2._2.Helpers;
namespace Tut_2._2.Models
{
    public class Student
    {
        [JsonPropertyName("indexNumber")]
        public string IndexNumber { get; set; }
        [JsonPropertyName("fname")]
        public string FirstName { get; set; }
        [JsonPropertyName("lname")]
        public string LastName { get; set; }
        [JsonPropertyName("bdate")]
        public DateTime BirthDate { get; set; }
        public string Email;
        

        [JsonPropertyName("mothersName")]
        public string MothersName { get; set; }
        [JsonPropertyName("fathersName")]
        public string FathersName { get; set; }
        public Helpers.Studies name { get; set; }
        public Helpers.Studies mode { get; set; }
        public Studies Studies { get; internal set; }
    }
}