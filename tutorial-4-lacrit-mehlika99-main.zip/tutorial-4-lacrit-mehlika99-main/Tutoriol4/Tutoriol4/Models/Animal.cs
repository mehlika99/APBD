﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Tutoriol4.Models
{
    public class Animal
    {
        internal int id;

        public int IdAnimal { get; set; }
        [Required(ErrorMessage = "NAME REQUIRED!")]
        [MaxLength(200, ErrorMessage = "Length of firstname cannot exceed 200")]
        public string Name { get; set; }
        public string Description { get; set; }
        [Required(ErrorMessage = "CATEGORY REQUIRED!")]
        [MaxLength(200, ErrorMessage = "Length of firstname cannot exceed 200")]
        public string Category { get; set; }
        [Required(ErrorMessage = "AREA REQUIRED!")]
        [MaxLength(200, ErrorMessage = "Length of firstname cannot exceed 200")]
        public string Area { get; set; }

        
       
    }
}
