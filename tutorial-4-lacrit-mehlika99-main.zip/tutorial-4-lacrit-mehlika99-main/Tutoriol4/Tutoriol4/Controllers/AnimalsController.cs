﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Tutoriol4.Models;

namespace Tutoriol4.Controllers
{
    [Route("api/animals")]
    [ApiController]
    public class AnimalsController : ControllerBase
    {
        [HttpGet]
        public IActionResult GetAnimals(string orderBy, string Name)
        {
            var animals = new List<Animal>();
            //sql connection//sql command
            //connection string Data Source=db-mssql;Initial Catalog=s20321;Integrated Security=True
            using (var con = new SqlConnection("Data Source=db-mssql;Initial Catalog=s20321;Integrated Security=True"))
            {
                using (var com = new SqlCommand())
                {
                    com.Connection = con;
                    con.Open();//open connection
                    com.CommandText = "select*from Animal Order By Name ASC,Description ASC,Category ASC,Area ASC";//query taht we want to see.
                    var dr = com.ExecuteReader();//exceute method
                    while (dr.Read())
                    {
                        var animal = new Animal//assign the fileds to animal
                        {
                            //checking do we have column name like that
                            IdAnimal = Int32.Parse(dr["IdAnimal"].ToString()),
                            Name = dr["Name"].ToString(),
                            Description = dr["Description"].ToString(),
                            Category = dr["Category"].ToString(),
                            Area = dr["Area"].ToString()

                        };
                        animals.Add(animal);



                    }

                }

            }
            return Ok(animals);
        }

        /*        [HttpGet]
        public IActionResult GetAnimals()
        {
            var animals = new List<Animal>();
            //sql connection//sql command
            //connection string Data Source=db-mssql;Initial Catalog=s20321;Integrated Security=True
            using (var con = new SqlConnection("Data Source=db-mssql;Initial Catalog=s20321;Integrated Security=True"))
            {
                using (var com = new SqlCommand())
                {
                    com.Connection = con;
                    con.Open();//open connection
                    com.CommandText = "select*from ";//query taht we want to see.
                    var dr = com.ExecuteReader();//exceute method
                    while (dr.Read())
                    {
                        var animal = new Animal//assign the fileds to animal
                        {
                            //checking do we have column name like that
                            IdAnimal = Int32.Parse(dr["IdAnimal"].ToString()),
                            Name = dr["Name"].ToString(),
                            Description = dr["Description"].ToString(),
                            Category = dr["Category"].ToString(),
                            Area = dr["Area"].ToString()

                        };
                        animals.Add(animal);

                    }

                }

            }
            return Ok(animals);
        }*/

        //adding new animal to the database
        [HttpPost]
        public IActionResult CreateAnimal(Animal animal)
        {
            using (SqlConnection con = new SqlConnection("Data Source=db-mssql;Initial Catalog=s20321;Integrated Security=True"))
            {
                using (SqlCommand com = new SqlCommand())
                {

                    var IdAnimal = $"s{new Random().Next(1, 20000)}";
                    com.Connection = con;
                    com.CommandText = "insert into animal values('" + IdAnimal + "',@par1,@par2,@par3,@par4,2);";
                    com.Parameters.AddWithValue("par1", animal.Name);
                    com.Parameters.AddWithValue("par2", animal.Description);
                    com.Parameters.AddWithValue("par3", animal.Category);
                    com.Parameters.AddWithValue("par4", animal.Area);
                    con.Open();
                    int affected = com.ExecuteNonQuery();

                    return Ok(affected);
                }

                
            }


        }

        //DELETING
        [HttpDelete("{idAnimal}")]
        public IActionResult DeleteAnimal(string idAnimal)
        {
            string tmp = "";
            using (var client = new SqlConnection("Data Source=db-mssql;Initial Catalog=s20321;Integrated Security=True"))
            {

                using (var command = new SqlCommand())
                {
                    command.Connection = client;
                    string query = "Delete IdAnimal From Animal;";
                    command.CommandText = (query);
                    client.Open();
                    var reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        tmp = $"{ reader["Animal"]}";
                    }
                }

            }
            return Ok("Animal Deleted");

        }

        //UPDATING
              [HttpPut("{idAnimal}")]
              public IActionResult UpdateAnimal(string idAnimal)
              {
                  string tmp = "";
                  using (var client = new SqlConnection("Data Source=db-mssql;Initial Catalog=s20321;Integrated Security=True"))
                  {

                      using (var command = new SqlCommand())
                      {
                          command.Connection = client;
                          string query = "Update Name From Animal;";
                          command.CommandText = (query);
                          client.Open();
                          var reader = command.ExecuteReader();
                          while (reader.Read())
                          {
                              tmp = $"{ reader["Animal"]}";
                          }
                      }

                  }
                  return Ok("Animal Updated");

              }
       

    }
}
