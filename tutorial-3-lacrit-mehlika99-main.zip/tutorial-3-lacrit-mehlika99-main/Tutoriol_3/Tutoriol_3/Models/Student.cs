﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Tutoriol_3.Models
{
    public class Student
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string IndexNumber { get; set; }
        
        public string studies { get; set; }
        public string mode { get; set; }

        public string Email;
        public string FathersName { get; set; }
        public string MothersName { get; set; }

      
    }
}
