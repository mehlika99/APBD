﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Tutoriol_3.Models;
using Tutoriol_3.Service;

namespace Tutoriol_3.Controllers
{
    //HTTP GET api/students
    //HTTP GET api/students/s1234
    //HTTP PATCH - partial update
    //HTTP PUT - update the whole resource
    //HTTP POST api/students  - add sth to db
    //HTTP DELETE api/students

    [Route("api/students")]//address
    [ApiController]//marks our controller as an api
    public class StudentsController : ControllerBase//handling the request//inheritance from controlbase
    {
        //REST - we have certain resources
        // Each resource have an identifier

    

        public static List<Student> _students = new List<Student>();

        [HttpGet("{indexNumber}")]
        public IActionResult GetStudent(string indexNumber)//pasising the snumber data using url segment
        {

            var list = new List<Student>();
          
                list.Add(new Student
                {
                    FirstName = "Mehlika",
                    LastName = "Bilgicli",
                    IndexNumber = "s2032",
                    studies = "IT",
                    mode = "Daily",
                    Email = "mehlika@wp.pl",
                    FathersName = "Omer",
                    MothersName = "Zeynep"



                });
            if (list != null)

                return Ok(list);
            else return NotFound("nobody found");

        }


       /* [HttpGet]
        public IActionResult GetStudents(string orderBy)
        {
         

            var list = new List<Student>();
           
            list.Add(new Student
            {
                 FirstName = "Mehlika",
                 LastName = "Bilgicli",
                 IndexNumber = "s2032",
                 studies = "IT",
                 mode = "Daily",
                 Email = "mehlika@wp.pl",
                 FathersName = "Omer",
                 MothersName = "Zeynep"
               
            });

            return Ok(list);
        }*/

        [HttpGet]
        public IActionResult GetStudents()
        {
            List<Student> list = new List<Student>();
            StreamReader st = new StreamReader((new FileInfo("./Data/students.csv")).OpenRead());
            string line = null;
            while ((line = st.ReadLine()) != null)
            {
                string[] a = line.Split(",");
                var student = new Student
                {
                    FirstName = a[0],
                    LastName = a[1],
                    IndexNumber = a[2],
                    studies = a[3],
                    mode = a[4],
                    Email = a[5],
                    FathersName = a[6],
                    MothersName = a[7]

                };
                list.Add(student);

            }
            return Ok(list);
            //return Ok(_students);

        }

        [HttpPost]
        public IActionResult CreateStudent(Student student)//add new student,create new student
        {
            //adding to database
            _students.Add(student);
            student.IndexNumber = $"s{new Random().Next(1, 20000)}";
           
            return Ok(student);
        }
        Student student = new Student();

        /*[HttpPut("{indexNumber}")]//update
        public IActionResult PutStudent(string indexNumber)
        {
            
            return Ok("UPDATED");
        }*/

        [HttpPut]
        public IActionResult UpdateStudent(Student student)
        {
            if (student != null)
            {
                UpdateStudent(student);
                return Ok("UPDATED");
            }

            return NotFound("Student doesnt exist");
        }

        [HttpDelete("{indexNumber}")]//removing element
        public IActionResult DeleteStudent(string indexNumber)
        {
            DeleteStudent(indexNumber);
            return Ok("DELETED");
        }
    }
}
