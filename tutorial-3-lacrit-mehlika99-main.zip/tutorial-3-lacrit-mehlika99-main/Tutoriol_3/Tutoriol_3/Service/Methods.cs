﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Tutoriol_3.Models;

namespace Tutoriol_3.Service
{
    public class Methods
    {

       
        public static List<Student> UpdateStudent()
        {
            List<Student> list = new List<Student>();
            StreamReader st = new StreamReader((new FileInfo("./Data/students.csv")).OpenRead());
            string line = null;
            while ((line = st.ReadLine()) != null)
            {
                string[] a = line.Split(",");
                var student = new Student
                {
                    FirstName = a[0],
                    LastName = a[1],
                    IndexNumber = a[2],
                    studies = a[3],
                    mode = a[4],
                    Email = a[5],
                    FathersName = a[6],
                    MothersName = a[7]

                };
                list.Add(student);

            }
            return list;
        }

        public static List<Student> DeleteStudent()
        {
            List<Student> list = new List<Student>();
            StreamReader st = new StreamReader((new FileInfo("./Data/students.csv")).OpenRead());
            string line = null;
            while ((line = st.ReadLine()) != null)
            {
                string[] a = line.Split(",");
                var student = new Student
                {
                    FirstName = a[0],
                    LastName = a[1],
                    IndexNumber = a[2],
                    studies = a[3],
                    mode = a[4],
                    Email = a[5],
                    FathersName = a[6],
                    MothersName = a[7]

                };
                list.Remove(student);

            }
            return list;
        }

        public static List<Student> GetStudentss()
        {
            List<Student> list = new List<Student>();
            StreamReader st = new StreamReader((new FileInfo("./Data/students.csv")).OpenRead());
            string line = null;
            while ((line = st.ReadLine()) != null)
            {
                string[] a = line.Split(",");
                var student = new Student
                {
                    FirstName = a[0],
                    LastName = a[1],
                    IndexNumber = a[2],
                    studies = a[3],
                    mode = a[4],
                    Email = a[5],
                    FathersName = a[6],
                    MothersName = a[7]

                };
                list.Add(student);

            }
            return list;
        }




    }
}

