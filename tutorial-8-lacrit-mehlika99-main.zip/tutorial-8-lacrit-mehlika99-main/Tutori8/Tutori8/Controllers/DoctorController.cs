﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Tutori8.DTO;
using Tutori8.Models;

namespace Tutori8.Controllers
{
    [Route("api/doctor")]
    [ApiController]
    public class DoctorController : ControllerBase
    {
        private readonly ClinicDbContext _context;
        public DoctorController(ClinicDbContext context)
        {
            _context = context;
        }

        //all doctors data
        [HttpGet]
        public IActionResult GetDoctors()
        {
            try
            {
                return Ok(_context.Doctors.ToList());
            }
            catch (Exception e) { return BadRequest(e); }

        }
        //given id doctor data
        [HttpGet("{id}")]
        public IActionResult GivenIdDoctorData(int id)
        {
            var res = _context.Doctors.Any(e => e.IdDoctor == id);

            if (res == true)
            {
                var res2 = _context.Doctors.Include(e => e.Prescriptions)
                                                       .Where(e => e.IdDoctor == id)
                                                       .Select(e => new {
                                                           e.IdDoctor,
                                                           e.FirstName,
                                                           e.LastName,
                                                           e.Email,
                                                           PrescriptionList = e.Prescriptions
                                                           .Select(e => e.IdPresciption)
                                                           .ToList()
                                                       });
                return Ok(res2);
            }
            else
            {
                throw new Exception("There is nothing!");
            }

        }

        //add doctor
        [HttpPost("add")]
        public IActionResult AddDoctor(Doctor doctor)
        {
            var res = _context.Doctors.Any(e => e.IdDoctor == doctor.IdDoctor);
            if (res == true)
            {
                return BadRequest("There is a doctor with this id already!");

            }
            else
            {

                _context.Doctors.Add(doctor);
                _context.SaveChanges();
                 return Ok("New Doctor Added!");
               
            }
        }

        //delete doctor
        [HttpDelete("delete")]
        public IActionResult DeleteDoctor(int id)
        {
            var res = _context.Doctors.Any(e => e.IdDoctor == id);
            if (res == true)
            {
                var res2 = _context.Doctors.Find(id);
                _context.Doctors.Remove(res2);
                _context.SaveChanges();
                return Ok(id + "deleted!");
                
            }
            else
            {
                return NotFound("There is no record!");
            }
        }

        //modify doctor
        [HttpPost("modify")]
        public IActionResult ModifyDoctor(Doctor doctor)
        {
            try
            {
                var res = _context.Doctors
                    .Where(e => e.IdDoctor == doctor.IdDoctor)
                    .ToList();

                Doctor res2 = res.First();

                res2.FirstName = doctor.FirstName;
                res2.LastName = doctor.LastName;
                res2.Email = doctor.Email;

                _context.Update(res2);

                _context.SaveChanges();
                return Ok(doctor.IdDoctor + "Modified");
            }
            catch (Exception e)
            {
                return BadRequest(e);
            }
        }

        //trying to get third point of the task
        [HttpGet]
        public IActionResult DowloandPrescription()
        {
            var pres = _context.Prescriptions.Select(p => new PrescriptionRe
            {
                IdDoctor = p.IdDoctor,

                IdPatient = p.IdPatient,

                IdPrescription = p.IdPresciption,

                //IdMedicament = p.IdMedicament
            }).AsEnumerable();

            return Ok(pres);
        }

    }
}
