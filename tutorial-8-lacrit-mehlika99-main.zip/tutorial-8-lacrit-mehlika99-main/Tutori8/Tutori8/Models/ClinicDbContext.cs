﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Tutori8.Models
{
    public class ClinicDbContext:DbContext
    {
        public DbSet<Doctor> Doctors { get; set; }
        public DbSet<Prescription> Prescriptions { get; set; }
        public DbSet<Medicament> Medicaments { get; set; }
        public DbSet<Patient> Patients { get; set; }
        public DbSet<Prescription_Medicament> Prescription_Medicaments { get; set; }
        public ClinicDbContext()
        {

        }
        public ClinicDbContext(DbContextOptions options):base(options)
        {

        }
        
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Doctor>(entity =>
            {
                entity.HasKey(e => e.IdDoctor);
                entity.Property(e => e.IdDoctor).ValueGeneratedOnAdd();
                entity.Property(e => e.FirstName).IsRequired();

                entity.ToTable("Doctor");

                entity.HasMany(d => d.Prescriptions)
                       .WithOne(p => p.Doctor)
                       .HasForeignKey(p => p.IdDoctor)
                       .IsRequired();
            });

            modelBuilder.Entity<Prescription>(entity =>
            {
                entity.HasKey(e => e.IdPresciption);
                entity.Property(e => e.IdPresciption).ValueGeneratedOnAdd();
                entity.ToTable("Prescription");

                entity.HasMany(d => d.Prescription_Medications)
                       .WithOne(p => p.Prescription)
                       .HasForeignKey(p => p.IdPrescription)
                       .IsRequired();

            });

            modelBuilder.Entity<Patient>(entity =>
            {
                entity.HasKey(e => e.IdPatient);
                entity.Property(e => e.IdPatient).ValueGeneratedOnAdd();
                entity.Property(e => e.FirstName).IsRequired();
                entity.ToTable("Patient");

                entity.HasMany(d => d.Prescriptions)
                       .WithOne(p => p.Patient)
                       .HasForeignKey(p => p.IdPatient)
                       .IsRequired();

            });

            modelBuilder.Entity<Medicament>(entity =>
            {
                entity.HasKey(e => e.IdMedicament);
                entity.Property(e => e.IdMedicament).ValueGeneratedOnAdd();
                entity.Property(e => e.Name).IsRequired();
                entity.ToTable("Medicament");

                entity.HasMany(d => d.Prescription_Medicaments)
                       .WithOne(p => p.Medicament)
                       .HasForeignKey(p => p.IdMedicament)
                       .IsRequired();


            });

            modelBuilder.Entity<Prescription_Medicament>(entity =>
            {
                entity.HasKey(e => new { e.IdMedicament, e.IdPrescription });
                entity.Property(e => e.Dose).IsRequired();
                entity.ToTable("Prescription_Medicament");


            });

            Seed(modelBuilder);

        }
        public static void Seed(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Doctor>().HasData(
            new Models.Doctor { IdDoctor = 1, FirstName = "Max", LastName = "Walt", Email = "maxwal@gmail.com" },
            new Models.Doctor { IdDoctor = 2, FirstName = "Mehlika", LastName = "Bilg", Email = "mehlbil@gmail.com" },
            new Models.Doctor { IdDoctor = 3, FirstName = "Alex", LastName = "Quen", Email = "alexque@gmail.com" });

            modelBuilder.Entity<Patient>().HasData(
            new Models.Patient { IdPatient = 1, FirstName = "Reck", LastName = "Kal", Birthdate = new DateTime(1999, 9, 19) },
            new Models.Patient { IdPatient = 2, FirstName = "Bartu", LastName = "Bilir", Birthdate = new DateTime(2000, 3, 2) },
            new Models.Patient { IdPatient = 3, FirstName = "Nesli", LastName = "Verici", Birthdate = new DateTime(1997, 10, 9) });


            modelBuilder.Entity<Medicament>().HasData(
            new Models.Medicament { IdMedicament = 1, Name = "Tayloth", Description = "for cold", Type = "pill" },
            new Models.Medicament { IdMedicament = 2, Name = "Afferin", Description = "for pain", Type = "syrup" },
            new Models.Medicament { IdMedicament = 3, Name = "Parol", Description = "for pain", Type = "pill" });

            modelBuilder.Entity<Prescription>().HasData(
            new Models.Prescription { IdPresciption = 1, Date = new DateTime(2021, 9, 1), DueDate = new DateTime(2021, 9, 28), IdPatient = 1, IdDoctor = 1 },
            new Models.Prescription { IdPresciption = 2, Date = new DateTime(2021, 4, 2), DueDate = new DateTime(2021, 4, 27), IdPatient = 2, IdDoctor = 2 },
            new Models.Prescription { IdPresciption = 3, Date = new DateTime(2021, 2, 10), DueDate = new DateTime(2021, 2, 25), IdPatient = 3, IdDoctor = 3 });

            modelBuilder.Entity<Prescription_Medicament>().HasData(
            new Models.Prescription_Medicament { IdPrescription = 1, IdMedicament = 1, Dose = 1, Details = "every year twice" },
            new Models.Prescription_Medicament { IdPrescription = 2, IdMedicament = 2, Dose = 2, Details = "once a day" },
            new Models.Prescription_Medicament { IdPrescription = 3, IdMedicament = 3, Dose = 1, Details = "per week twice" });
        }
    }
}
