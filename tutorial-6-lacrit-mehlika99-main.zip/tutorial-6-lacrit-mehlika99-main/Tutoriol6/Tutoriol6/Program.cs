﻿using System;

namespace Tutoriol6
{
    class Program
    {
        static void Main(string[] args)
        {
            System.Collections.Generic.IEnumerable<Models.Emp> t =  LinqTasks.Task1();
            System.Collections.Generic.IEnumerable<Models.Emp> t2 = LinqTasks.Task2();
            int t3= LinqTasks.Task3();
            System.Collections.Generic.IEnumerable<Models.Emp> t4 = LinqTasks.Task4();
            System.Collections.Generic.IEnumerable<object> t5 = LinqTasks.Task5();
            System.Collections.Generic.IEnumerable<object> t6 = LinqTasks.Task6();
            System.Collections.Generic.IEnumerable<object> t7 = LinqTasks.Task7();
            bool t8 = LinqTasks.Task8();
            Models.Emp t9 = LinqTasks.Task9();
            System.Collections.Generic.IEnumerable<object> t10 = LinqTasks.Task10();
            System.Collections.Generic.IEnumerable<object> t11 = LinqTasks.Task11();
            System.Collections.Generic.IEnumerable<Models.Emp> t12 = LinqTasks.Task12();
            System.Collections.Generic.IEnumerable<Models.Dept> t14 = LinqTasks.Task14();

        }
    }
}
