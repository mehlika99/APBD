﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Test.Models;

namespace Test.DTO
{
    public class Response
    {
        public int IdOrganiser { get; set; }
        public string Name { get; set; }
        public List<Event> Events { get; set; }
    }
}
