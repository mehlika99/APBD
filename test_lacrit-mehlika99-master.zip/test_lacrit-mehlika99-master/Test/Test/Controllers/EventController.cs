﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Test.Services;

namespace Test.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EventController : ControllerBase
    {
        private readonly IDbService _dbService;


        public EventController(IDbService dbService)
        {
            _dbService = dbService;
        }

        [HttpGet("organizers/{id}")]
        public IActionResult GetOrder(int id)
        {
            var res1 = _dbService.GetOrginizer(id);
            if (res1.ToList().Count() != 0)
                return Ok(res1);
            else
                return NotFound("There is no organizer with this ID");
        }
    }
}
