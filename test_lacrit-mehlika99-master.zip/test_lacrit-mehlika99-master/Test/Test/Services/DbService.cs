﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Test.DTO;
using Test.Models;

namespace Test.Services
{
    public class DbService: IDbService
    {
        private readonly TaskDbContext dbContext;

        public DbService(TaskDbContext _context)
        {
            dbContext = _context;
        }

        public IEnumerable<Response> GetOrginizer(int OrginiserId)
        {
            
            return dbContext.Organiser.Where(p => p.IdOrganiser == OrginiserId).Select(e => new Response
            {
                IdOrganiser = e.IdOrganiser,
                Name = e.Name,
                Events = dbContext.Event
                        .Where(d => d.IdEvent == e.Event_Organiser.Select(z => z.IdEvent).FirstOrDefault())
                        .OrderBy(ev => ev.StartDate).ToList()
            }
            );
        }

       
    }
}
