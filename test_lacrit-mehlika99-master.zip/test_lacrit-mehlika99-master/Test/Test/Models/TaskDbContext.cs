﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Test.Models
{
    public class TaskDbContext:DbContext
    {
        public DbSet<Artist> Artist { get; set; }
        public DbSet<Artist_Event> Artist_Event { get; set; }
        public DbSet<Event> Event { get; set; }
        public DbSet<Event_Organiser> Event_Organiser { get; set; }
        public DbSet<Organiser> Organiser { get; set; }
        
        
        

        public TaskDbContext(DbContextOptions<TaskDbContext> options) : base(options)
        {
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Artist>(entity =>
            {
                entity.HasKey(e => e.IdArtist);
                entity.Property(e => e.Nickname).HasMaxLength(30).IsRequired();
            });



            modelBuilder.Entity<Artist_Event>(entity =>
            {
                entity.HasKey(e => new { e.IdArtistEvent });
                entity.Property(e => e.PerformanceDate).HasDefaultValueSql("GETDATE()").IsRequired();
                entity.HasOne(e => e.Event)
                    .WithMany(d => d.Artists_Event)
                    .HasForeignKey(p => p.IdEvent)
                    .OnDelete(DeleteBehavior.Restrict)
                    ;
                entity.HasOne(e => e.Artist)
                    .WithMany(d => d.Artists_Event)
                    .HasForeignKey(p => p.IdArtist)
                    .OnDelete(DeleteBehavior.Restrict)
                    ;
            });


            modelBuilder.Entity<Event>(entity =>
            {
                entity.HasKey(e => e.IdEvent);
                entity.Property(e => e.Name).HasMaxLength(100).IsRequired();
                entity.Property(e => e.StartDate).HasDefaultValueSql("GETDATE()").IsRequired();
                entity.Property(e => e.EndDate).IsRequired();
            });


            modelBuilder.Entity<Organiser>(entity =>
            {
                entity.HasKey(e => e.IdOrganiser);
                entity.Property(e => e.Name).HasMaxLength(30).IsRequired();
            });


            modelBuilder.Entity<Event_Organiser>(entity =>
            {
                entity.HasKey(e => new { e.IdEventOrganiser });
                entity.HasOne(e => e.Organiser)
                    .WithMany(d => d.Event_Organiser)
                    .HasForeignKey(p => p.IdOrganiser)
                    .OnDelete(DeleteBehavior.Restrict)
                    ;
                entity.HasOne(e => e.Event)
                    .WithMany(d => d.Event_Organiser)
                    .HasForeignKey(p => p.IdEvent)
                    .OnDelete(DeleteBehavior.Restrict)
                    ;
            });

            modelBuilder.Entity<Organiser>().HasData(
                new Organiser
                {
                    IdOrganiser = 1,
                    Name = "MEHLIKA"
                }
            );
            modelBuilder.Entity<Artist>().HasData(
                new Artist
                {
                    IdArtist = 1,
                    Nickname = "MELIS"
                }
            );
            modelBuilder.Entity<Event>().HasData(
                new Event
                {
                    IdEvent = 1,
                    Name = "Fajny Event",
                    StartDate = DateTime.Now,
                    EndDate = DateTime.Now,
                }
            );
            modelBuilder.Entity<Artist_Event>().HasData(
                new Artist_Event
                {
                    IdEvent = 1,
                    IdArtist = 1,
                    PerformanceDate = DateTime.Now,
                }
            );

            modelBuilder.Entity<Event_Organiser>().HasData(
                new Event_Organiser
                {
                    IdEvent = 1,
                    IdOrganiser = 1,
                }
            );

        }



    }
}
