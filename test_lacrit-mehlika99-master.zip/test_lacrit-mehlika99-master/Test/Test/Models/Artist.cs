﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Test.Models
{
    [Table("Artist")]
    public class Artist
    {
        [Key]
        public int IdArtist { get; set; }

        [Required]
        [MaxLength(100)]
        public string Nickname { get; set; }

        public virtual ICollection<Artist_Event> Artists_Event { get; set; }

    }
}
