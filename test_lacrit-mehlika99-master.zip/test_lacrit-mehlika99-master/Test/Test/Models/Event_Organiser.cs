﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Test.Models
{
    public class Event_Organiser
    {
        [Key]
        public int IdEventOrganiser { get; set; }
        public int IdEvent { get; set; }
        public int IdOrganiser { get; set; }
        public virtual Event Event { get; set; }

        public virtual Organiser Organiser { get; set; }
    }
}
