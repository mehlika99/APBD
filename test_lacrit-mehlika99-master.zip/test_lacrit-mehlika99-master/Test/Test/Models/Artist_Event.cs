﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Test.Models
{
    
    public class Artist_Event
    {
        [Key]
        public int IdArtistEvent { get; set; }
        public int IdEvent { get; set; }
        public int IdArtist { get; set; }
        public DateTime PerformanceDate { get; set; }

        public virtual Artist Artist { get; set; }

        public virtual Event Event { get; set; }
    }
}
