﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Tut7.Models;

namespace Tut7.Service
{
    [Route("api/clients")]
    [ApiController]
    public class ValuesController : ControllerBase
    {
        private readonly ILogger<ValuesController> _logger;
        private readonly ITripDbContext _context;

        public ValuesController(ILogger<ValuesController> logger, ITripDbContext context)
        {
            _logger = logger;
            _context = context;
        }
       /* [HttpGet]
        public IActionResult Get()
        {
            List<Client> clients = _context.Clients.Where(x => x.LastName.StartsWith("s")).ToList();//clients last name starts with s
            return Ok(clients);
        }*/
    }
}
