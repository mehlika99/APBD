﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Tut7.Models;
using Tut7.Models.Dtos;

using Tut7.Models.Dtos.Response;

namespace Tut7.Service
{
    public interface IDbService
    {
        public IEnumerable<GetClientStatistiscsResponseDto> GetReport();
    }

    public class DatabaseService : IDbService
    {
        private readonly TripDbContext _context;

        public DatabaseService(TripDbContext context)
        {
            _context = context;
        }

        public IEnumerable<GetClientStatistiscsResponseDto> GetReport()
        {
            return _context.Clients
                           .Select(c => new GetClientStatistiscsResponseDto
                           {

                           });
        }
        public bool AssignClient(CreateClientAndTripRequestDto req)
        {
            var res = _context.Clients.FirstOrDefault(c => c.Pesel.Equals(req.Pesel));

            if (res == null)
            {
                var newClient = new Client
                {
                    IdClient = _context.Clients.Max(c => c.IdClient) + 1,
                    FirstName = req.FirstName,
                    LastName = req.LastName,
                    Email = req.Email,
                    Pesel = req.Pesel,
                    Telephone = req.Telephone
                };

                _context.Clients.Add(newClient);
                _context.SaveChanges();

                res = _context.Clients.FirstOrDefault(c => c.Pesel.Equals(req.Pesel));
            }

            var tripSign = _context.ClientTrips.FirstOrDefault(t => t.IdTrip == req.IdTrip);

            if (tripSign != null)
                return false;

            var tourCheck = _context.Trips.FirstOrDefault(t => t.IdTrip == req.IdTrip && t.Name.Equals(req.TripName));

            if (tourCheck == null)
                return false;

          
            _context.SaveChanges();

            return true;
        }
    }
}
