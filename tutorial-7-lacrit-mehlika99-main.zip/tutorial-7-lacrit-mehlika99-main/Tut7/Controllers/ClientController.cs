﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Tut7.Models;
using Tut7.Models.Dtos;
using Tut7.Models.Dtos.Response;

namespace Tut7.Controllers
{
  

    [Route("api/client")]
    [ApiController]
    public class ClientController : ControllerBase
    {
        private readonly TripDbContext _tripDbContext;
        public ClientController(TripDbContext tripDbContext)
        {
            _tripDbContext = tripDbContext;
        }
        //return the list of trips 
        [HttpGet]
        public IActionResult GetTrip()
        {
            var trips = _tripDbContext.Trips.Select(t => new { t.IdTrip ,t.Name ,t.Description ,t.DateFrom ,t.DateTo ,t.MaxPeople }).OrderByDescending(t => t.DateFrom).ToList();
           

            return Ok(trips);

        


        }
       

        //delete customer data
       [HttpDelete("{idClient}")]
        public IActionResult deleteClient(int idClient)
        {
         
            var assigned = false;

            if (_tripDbContext.ClientTrips.First(t => t.IdClient == idClient) != null);
            assigned = true;

            if (!assigned)
            {
                var res = _tripDbContext.Clients.First(c => c.IdClient == idClient);
                _tripDbContext.Clients.Remove(res);
                _tripDbContext.SaveChanges();
                return Ok("deleted!");
            }
            else
            {
                return NotFound("There is no client with this id!");
            }
            /*var del = _tripDbContext.Clients.Any(c => c.IdClient == idClient);
          if (del == true)
          {
              var res = _tripDbContext.Clients.Find(idClient);  
              _tripDbContext.Clients.Remove(res);
              _tripDbContext.SaveChanges();
              return Ok("deleted!");
          }
          else
          { 
              return NotFound("There is no client with this id!");
          }*/

        }

        [HttpPost("{idTrip}")]
        public async Task<IActionResult> assignClient(int idTrip)
        {
            string req = "";
            using (StreamReader reader = new StreamReader(Request.Body, Encoding.UTF8))
            {
                req = await reader.ReadToEndAsync();
            }

            CreateClientAndTripRequestDto assig = Deserialize(req);

            

            bool res = _tripDbContext.AssignClient(assig);

            

            return Ok();
        }

      


        /*[HttpGet]
        public async Task< IActionResult> GetClient()
        {
            var context = new TripDbContext();
            //var client = context.Clients
              //  .Where(c => c.LastName.StartsWith("B"))
              //  .OrderBy(c => c.LastName)
               // .ThenBy(c => c.FirstName);
            List<Client> client = await context.Clients
                .Include(context => context.ClientTrips)
                .ToListAsync();
            return Ok(client);
        }*/

        [HttpPost]
        public IActionResult CreateClientAndTrip(CreateClientAndTripRequestDto request)
        {
            var client = new Client
            {
                LastName = request.TripName
            };
            var trip = new Trip
            {
                Name = request.TripName
            };
            return Ok();
        }
        private CreateClientAndTripRequestDto Deserialize(string req)
        {
            throw new NotImplementedException();
        }




    }
}
