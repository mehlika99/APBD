﻿using System;
using System.Net.Http;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Crawler
{
    public class Program
    {
        public static async Task Main(string[] args)
        {
            int count = 0;
            if (args.Length == 0)
            {
                throw new ArgumentNullException();
            }

            string url = args[0];
            HttpClient httpClient = new HttpClient();

            try
            {

                HttpResponseMessage response = await httpClient.GetAsync(url);
                httpClient.Dispose();

                if (response.IsSuccessStatusCode)
                {
                    string content = await response.Content.ReadAsStringAsync();
                    var regex = new Regex("[a-z]+[a-z0-9-]*@[a-z-]+\\.[a-z]+", RegexOptions.IgnoreCase);
                    MatchCollection mail = regex.Matches(content);

                   
                    foreach (var matching in mail)
                    {
                        count += 1;
                        Console.WriteLine(matching.ToString());
                    }
                    if (count == 0)
                    {
                        Console.WriteLine("E-mail addresses not found");
                    }
                   
                }
                
            }
            catch (ArgumentException e)
            {
                Console.WriteLine(e.Message);
            }
            catch (Exception)
            {
                Console.WriteLine("Error while dowloanding the page.");
            }

        }

    }
}