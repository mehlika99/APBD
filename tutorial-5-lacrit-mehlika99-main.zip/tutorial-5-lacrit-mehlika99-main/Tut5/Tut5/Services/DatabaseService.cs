﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Tut5.Exceptions;
using Tut5.Models;

namespace Tut5.Services
{

    public class DatabaseService : DbService
    {
        private readonly string connectionString = "Data Source = db - mssql; Initial Catalog = s20321; Integrated Security = True";
        public async Task<int> AddProductToWarehouseAsync(Product_Warehouse product)
        {
            using var connection = new SqlConnection(connectionString);
            using var command = new SqlCommand();

            command.Connection = connection;
            await connection.OpenAsync();

            //We can add a product to the warehouse only if there is a product purchase order in the Order table.
            //Therefore, we check if there is a record in the Order table with IdProduct and Amount that matches our request
            //The CreatedAt of the order should be lower than the CreatedAt in the request.

            command.CommandText = "SELECT TOP 1 [Order].IdOrder FROM [Order] " +
                "LEFT JOIN Product_Warehouse ON [Order].IdOrder = Product_Warehouse.IdOrder " +
                "WHERE [Order].IdProduct = @IdProduct " +
                "AND [Order].Amount = @Amount " +
                "AND Product_Warehouse.IdProductWarehouse IS NULL " +
                "AND [Order].CreatedAt < @CreatedAt";

            command.Parameters.AddWithValue("IdProduct", product.IdProduct);
            command.Parameters.AddWithValue("IdWarehouse", product.IdWarehouse);
            command.Parameters.AddWithValue("Amount", product.Amount);
            command.Parameters.AddWithValue("CreatedAt", product.CreatedAt);

           

            var reader = await command.ExecuteReaderAsync();

            if (!reader.HasRows) throw new NoRow("There is no suitable order!");

            await reader.ReadAsync();
            int idOrder = int.Parse(reader["IdOrder"].ToString());
            await reader.CloseAsync();

            command.Parameters.Clear();

            

            command.CommandText = "SELECT IdWarehouse FROM Warehouse WHERE IdWarehouse = @IdWarehouse";
            command.Parameters.AddWithValue("IdWarehouse", product.IdWarehouse);

            reader = await command.ExecuteReaderAsync();

            if (!reader.HasRows) throw new NoRow("IdWarehouse does not exist!");

            await reader.CloseAsync();
            command.Parameters.Clear();




            command.CommandText = "SELECT Price FROM Product WHERE IdProduct = @IdProduct";
            command.Parameters.AddWithValue("IdProduct", product.IdProduct);

            reader = await command.ExecuteReaderAsync();

            if (!reader.HasRows) throw new NoRow("IdProduct does not exist!");

            await reader.ReadAsync();
            double price = double.Parse(reader["Price"].ToString());
            await reader.CloseAsync();

            command.Parameters.Clear();




            var transaction = (SqlTransaction)await connection.BeginTransactionAsync();
            command.Transaction = transaction;

            try
            {
                //We update the FullfilledAt column of the order with the current date and time. 
                command.CommandText = "UPDATE [Order] SET FulfilledAt =get.date() WHERE IdOrder = @IdOrder";
                command.Parameters.AddWithValue("CreatedAt", product.CreatedAt);
                command.Parameters.AddWithValue("IdOrder", idOrder);

                int rowsUpdated = await command.ExecuteNonQueryAsync();

                if (rowsUpdated < 1) throw new NoOutcome();

                command.Parameters.Clear();


                //We insert a record into the Product_Warehouse table. 
                //The Price column should corresponds to the price of the product multiplied by amount valuefrom our request.
                //Moreover, we insert the CreatedAt value according to the current time. 
                command.CommandText = "INSERT INTO Product_Warehouse(IdWarehouse, IdProduct, IdOrder, Amount, Price, CreatedAt) " +
                    $"VALUES(@IdWarehouse, @IdProduct, @IdOrder, @Amount, @Amount*{price}, @CreatedAt.{getdate()})";

                command.Parameters.AddWithValue("IdWarehouse", product.IdWarehouse);
                command.Parameters.AddWithValue("IdProduct", product.IdProduct);
                command.Parameters.AddWithValue("IdOrder", idOrder);
                command.Parameters.AddWithValue("Amount", product.Amount);
                command.Parameters.AddWithValue("CreatedAt", product.CreatedAt);

                int rowsInserted = await command.ExecuteNonQueryAsync();

                if (rowsInserted < 1) throw new NoOutcome();

                await transaction.CommitAsync();
            }
            catch (Exception)
            {
                await transaction.RollbackAsync();
            }

            command.Parameters.Clear();

            //As a result of the operation, we return the value of the primary key generated for the record inserted into the Product_Warehouse table.
            command.CommandText = "SELECT TOP 1 IdProductWarehouse from Product_Warehouse order by IdProductWarehouse DESC";

            reader = await command.ExecuteReaderAsync();

            await reader.ReadAsync();
            int idProductWarehouse = int.Parse(reader["IdProductWarehouse"].ToString());
            await reader.CloseAsync();

            await connection.CloseAsync();

            return idProductWarehouse;
        }

        private object getdate()
        {
            throw new NotImplementedException();
        }
    }
}
