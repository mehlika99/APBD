﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Tut5.Exceptions;
using Tut5.Models;

namespace Tut5.Services
{

    public class ProcedureDatabaseService : ProcedureDbService
    {
        private readonly string connectionString = "Data Source=db-mssql;Initial Catalog=s20321;Integrated Security=True";
        public async Task<int> AddProductToWarehouseAsync(Product_Warehouse product)
        {
            int idProductWarehouse = 0;

            using var connection = new SqlConnection(connectionString);
            using var command = new SqlCommand("AddProductToWarehouse", connection);

            var transaction = (SqlTransaction)await connection.BeginTransactionAsync();
            command.Transaction = transaction;

            try
            {
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("IdProduct", product.IdProduct);
                command.Parameters.AddWithValue("IdWarehouse", product.IdWarehouse);
                command.Parameters.AddWithValue("Amount", product.Amount);
                command.Parameters.AddWithValue("CreatedAt", product.CreatedAt);

                await connection.OpenAsync();
                int rowsChanged = await command.ExecuteNonQueryAsync();

                if (rowsChanged < 1) throw new NoOutcome();

                await transaction.CommitAsync();
            }
            catch (Exception)
            {
                await transaction.RollbackAsync();
                throw new Exception();
            }

            command.CommandType = CommandType.Text;
            command.CommandText = "SELECT IdProductWarehouse FROM Product_Warehouse ORDER BY IdProductWarehouse DESC";

            using var reader = await command.ExecuteReaderAsync();

            await reader.ReadAsync();
            if (await reader.ReadAsync())
                idProductWarehouse = int.Parse(reader["IdProductWarehouse"].ToString());
            await reader.CloseAsync();

            await connection.CloseAsync();

            return idProductWarehouse;
        }
    }
}
