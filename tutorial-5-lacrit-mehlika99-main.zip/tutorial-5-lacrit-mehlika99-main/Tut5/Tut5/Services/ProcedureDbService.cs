﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Tut5.Models;

namespace Tut5.Services
{
    public interface ProcedureDbService
    {
        Task<int> AddProductToWarehouseAsync(Product_Warehouse product);
    }
}
