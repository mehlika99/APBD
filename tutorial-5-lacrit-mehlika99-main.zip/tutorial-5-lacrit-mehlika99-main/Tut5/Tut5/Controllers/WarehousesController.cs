﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Tut5.Exceptions;
using Tut5.Models;
using Tut5.Services;

namespace Tut5.Controllers
{
    [Route("api/warehouses")]
    [ApiController]
    public class WarehousesController : ControllerBase
    {
        private readonly DbService DatabaseService;

        public WarehousesController(DbService DatabaseService)
        {
            this.DatabaseService = DatabaseService;
        }

        
        [HttpPost]
        public async Task<IActionResult> AddProductToWarehouse([FromBody] Product_Warehouse product)
        {
            int idProductWarehouse;
            try { 
                idProductWarehouse = await DatabaseService.AddProductToWarehouseAsync(product); 
            }
            catch (NoRow e) { 
                return NotFound(e.Message); 
            }
            catch (Exception e) { 
                return NotFound(e.Message); 
            }
            return Ok($"Id Added! ID: {idProductWarehouse}!");
        }
    }
}
