﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Tut5.Models;
using Tut5.Services;

namespace Tut5.Controllers
{
    [Route("api/warehouses2")]
    [ApiController]
    public class Warehouses2Controller : ControllerBase
    {
        private readonly ProcedureDbService ProcedureDatabaseService;

        public Warehouses2Controller(ProcedureDbService ProcedureDatabaseService)
        {
            this.ProcedureDatabaseService = ProcedureDatabaseService;
        }

        [HttpPost]
        public async Task<IActionResult> AddProductToWarehouse([FromBody] Product_Warehouse product)
        {
            int idProductWarehouse;
            try { 
                idProductWarehouse = await ProcedureDatabaseService.AddProductToWarehouseAsync(product); 
            }
            catch (Exception e) {
                return NotFound(e.Message); 
            }
            return Ok($"Id Added! ID: {idProductWarehouse}!");
        }
    }
}
