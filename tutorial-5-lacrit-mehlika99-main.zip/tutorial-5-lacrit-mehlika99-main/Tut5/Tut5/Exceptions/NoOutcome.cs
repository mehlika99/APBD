﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Threading.Tasks;

namespace Tut5.Exceptions
{
    public class NoOutcome:Exception
    {
        public NoOutcome()
        {
        }

        public NoOutcome(string message) : base(message)
        {
        }

        public NoOutcome(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected NoOutcome(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}
