﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Threading.Tasks;

namespace Tut5.Exceptions
{
    public class NoRow : Exception
    {
        public NoRow()
        {
        }

        public NoRow(string message) : base(message)
        {
        }

        public NoRow(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected NoRow(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}
