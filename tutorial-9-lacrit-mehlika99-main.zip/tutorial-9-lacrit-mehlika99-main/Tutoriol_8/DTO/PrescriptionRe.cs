﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Tutoriol_8.DTO
{
    public class PrescriptionRe
    {
        
            public int IdDoctor { get; set; }

            public int IdPatient { get; set; }

            public int IdPrescription { get; set; }

            public int IdMedicament { get; set; }
        
    }
}
