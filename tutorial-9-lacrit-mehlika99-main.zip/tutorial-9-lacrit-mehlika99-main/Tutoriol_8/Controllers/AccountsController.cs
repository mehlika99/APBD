﻿using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using Tutoriol_8.DTO;
using Tutoriol_8.Services;

namespace Tutoriol_8.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class AccountsController : ControllerBase
    {
        private IDoctorDbService _service;
        public IConfiguration Configuration { get; set; }

        public AccountsController(IConfiguration configuration, IDoctorDbService service)
        {
            Configuration = configuration;
            _service = service;
        }
        [AllowAnonymous]
        [HttpPost("login")]  //tokeni alip method calsitiriyoruz
        public IActionResult Login(LoginRequest request)  //it will generate new token
        {

            bool validation = _service.validationCredential(request.Login, request.Password);


            if (validation == false)
            {
                return Unauthorized("incorrect username or password");
            }

            var claims = new[]
            {
                new Claim(ClaimTypes.NameIdentifier, request.Login),
                new Claim(ClaimTypes.Name,"name1" ),  
                new Claim(ClaimTypes.Role, "doctor"),
                 

            };

            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(Configuration["SecretKey"]));
            //signing token
            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            var token = new JwtSecurityToken
            (
                issuer: "Meh",  //who issues this token
                audience: "Doctors",  //who can access it 
                claims: claims,
                expires: DateTime.Now.AddMinutes(10),
                signingCredentials: creds //used for encode this token
            );

            
            var refreshToken = Guid.NewGuid();   
            _service.assignRefreshToken(request.Login, refreshToken);

            return Ok(new
            {
                token = new JwtSecurityTokenHandler().WriteToken(token),
                refreshToken

            });


        }

        [AllowAnonymous]
        [HttpPost("refresh")]//endpoint for refreshing token
        public IActionResult refreshToken(TokenRequest requestToken)
        {
            bool refresh = _service.checkrefreshToken(requestToken.refreshToken);


            if (refresh == false)
            {
                return Unauthorized("incorrect refresh token!");
            }

            var claims = new[]
           {
                
                new Claim(ClaimTypes.Name,"name1" ),
                new Claim(ClaimTypes.Role, "admin"),
                new Claim(ClaimTypes.Role, "doctor"),
                

            };

            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(Configuration["SecretKey"]));
            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            var token = new JwtSecurityToken
            (
                issuer: "Meh",
                audience: "Doctors",
                claims: claims,
                expires: DateTime.Now.AddMinutes(10),
                signingCredentials: creds
            );



            var newrefreshToken = Guid.NewGuid();
            _service.updateRefreshToken(requestToken.refreshToken, newrefreshToken);

            return Ok(new
            {
                token = new JwtSecurityTokenHandler().WriteToken(token),
                newrefreshToken

            });
        }

    }
}
