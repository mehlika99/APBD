﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Tutoriol_8.Models;
using Tutoriol_8.Services;

namespace Tutoriol_8.Controllers
{
    
    [Route("api/doctor")]
    [ApiController]
    public class DoctorController : ControllerBase
    {
        IDoctorDbService _service;
        public IConfiguration Configuration { get; set; }
        public DoctorController(IDoctorDbService service, IConfiguration configuration)
        {
            _service = service;
            Configuration = configuration;
        }






        //+++++++++++++++++++++++++++++++++++++++++++
        [HttpGet]
        public IActionResult getDoctors()
        {
            var res1 = _service.getDoctors();
            return Ok(res1);
        }

        [HttpGet("{id}")]
        public IActionResult getDoctor(int id)
        {
            var res2 = _service.getDoctor(id);

            return Ok(res2);
        }
        [HttpPost]
        public IActionResult addDoctor(Doctor doctor)
        {
            var res3 = _service.addDoctor(doctor);
            return Ok(res3);

        }
        [HttpPut]
        public IActionResult modifyDoctor(Doctor doctor)
        {
            var res4 = _service.modifyDoctor(doctor);
            return Ok(res4);
        }

        [HttpDelete("{id}")]
        public IActionResult deleteDoctor(int id)
        {
            var res5 = _service.deleteDoctor(id);
            return Ok(res5);
        }

        //trying to get third point of the task///???
        [HttpGet]
        public IActionResult getPrescription()
        {
            var res6 = _service.getPrescription();
            return Ok(res6);
        }
    }
}
