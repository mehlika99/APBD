﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Tutoriol_8.DTO;
using Tutoriol_8.Models;

namespace Tutoriol_8.Services
{
    public interface IDoctorDbService
    {
        IQueryable getDoctors();
        IQueryable getDoctor(int id);
        string addDoctor(Doctor doctor);
        string modifyDoctor(Doctor doctor);
        string deleteDoctor(int id);
        IQueryable getPrescription();

        
        bool checkrefreshToken(string token);
        void updateRefreshToken(string oldtoken, Guid newtoken);
        bool validationCredential(string login, string password);
        void assignRefreshToken(string login, Guid rtoken);


    }
}
