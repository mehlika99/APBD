﻿using Microsoft.AspNetCore.Cryptography.KeyDerivation;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Tutoriol_8.DTO;
using Tutoriol_8.Helpers;
using Tutoriol_8.Models;

namespace Tutoriol_8.Services
{
    public class SqlServerDoctorDbService
    {
        private readonly ClinicDbContext _context;
        public SqlServerDoctorDbService(ClinicDbContext context)
        {
            _context = context;
        }
        //+++++++++++++++++++
        public bool validationCredential(string login, string password)
        {

            var hashfunc = new PasswordHelper();


            using (SqlConnection con = new SqlConnection(@"Data Source=db-mssql;Initial Catalog=s20321;Integrated Security=True"))
            using (SqlCommand com = new SqlCommand())
            {
                com.Connection = con;
                com.CommandText = "Select IdDoctor ,password,salt  From doctor where IdDoctor =@login ";
                com.Parameters.AddWithValue("login", login);

                con.Open();


                var dr = com.ExecuteReader();
                if (dr.Read())
                {
                    var salt = dr["salt"].ToString();
                    var s = dr["password"].ToString();


                    if (!hashfunc.validate(password, salt, s))
                    {
                        return false;
                    }
                    else
                    {

                        return true;

                    }
                }
                return false;

            }

        }
        //+++++++++++
        public void assignRefreshToken(string login, Guid rtoken)
        {
            using (SqlConnection con = new SqlConnection(@"Data Source=db-mssql;Initial Catalog=s20321;Integrated Security=True"))
            using (SqlCommand com = new SqlCommand())
            {
                com.Connection = con;
                com.CommandText = "Update doctor set refreshtoken= @refresh where IdDoctor =@login";
                com.Parameters.AddWithValue("refresh", rtoken);
                com.Parameters.AddWithValue("login", login);
                con.Open();


                com.ExecuteNonQuery();

            }

        }


        //+++++++++++++++++++++++++
        public bool checkrefreshToken(string token)
        {
            using (SqlConnection con = new SqlConnection(@"Data Source=db-mssql;Initial Catalog=s20321;Integrated Security=True"))
            using (SqlCommand com = new SqlCommand())
            {
                com.Connection = con;
                com.CommandText = "Select * From doctor where refreshtoken =@token; ";
                com.Parameters.AddWithValue("token", token);
                con.Open();
                var dr = com.ExecuteReader();
                if (dr.Read())
                {
                    return true;
                }
                return false;

            }
        }
        //+++++++++++++++++++++++++
        public void updateRefreshToken(string oldtoken, Guid newtoken)
        {

            using (SqlConnection con = new SqlConnection(@"Data Source=db-mssql;Initial Catalog=s20321;Integrated Security=True"))
            using (SqlCommand com = new SqlCommand())
            {
                com.Connection = con;
                com.CommandText = "Update doctor set refreshtoken= @newrefresh where refreshtoken =@old";
                com.Parameters.AddWithValue("newrefresh", newtoken);
                com.Parameters.AddWithValue("old", oldtoken);

                con.Open();


                com.ExecuteNonQuery();

            }

        }
        //+++++++++++++++++++++++++


        public string addDoctor(Doctor doctor)
        {
            var res = _context.Doctors.Any(e => e.IdDoctor == doctor.IdDoctor);
            if (res == true)
            {
               
                throw new Exception("There is a doctor with this id!");

            }
            else
            {

                _context.Doctors.Add(doctor);
                _context.SaveChanges();
               
                return "Succesfully added!";
            }
        }

        public string deleteDoctor(int id)
        {
            var res = _context.Doctors.Any(e => e.IdDoctor == id);
            if (res == true)
            {
                var res2 = _context.Doctors.Find(id);
                _context.Doctors.Remove(res2);
                _context.SaveChanges();
                
                return "Succesfully deleted!";
            }
            else
            {
               
                throw new Exception("There is no  such record!");
            }
        }

        public IQueryable getDoctor(int id)
        {
            var res = _context.Doctors.Any(e => e.IdDoctor == id);

            if (res == true)
            {
                var res2 = _context.Doctors.Include(e => e.Prescriptions)
                                                       .Where(e => e.IdDoctor == id)
                                                       .Select(e => new {
                                                           e.IdDoctor,
                                                           e.FirstName,
                                                           e.LastName,
                                                           e.Email,
                                                           PrescriptionList = e.Prescriptions
                                                           .Select(e => e.IdPresciption)
                                                           .ToList()
                                                       });

                
                return res2;
            }
            else
            {

                
                throw new Exception("There is no  such record!");
            }
        }

        public IQueryable getDoctors()
        {
            var res = _context.Doctors.Include(e => e.Prescriptions)
                                                        .Select(e => new {
                                                            e.IdDoctor,
                                                            e.FirstName,
                                                            e.LastName,
                                                            e.Email,
                                                            PrescriptionList = e.Prescriptions
                                                                                        .Select(e => e.IdPresciption)
                                                                                        .ToList()
                                                        });

            
            return res;
        }

        public string modifyDoctor(Doctor doctor)
        {
            var res = _context.Doctors.Any(e => e.IdDoctor == doctor.IdDoctor);

            if (res == true)
            {
                var res2 = _context.Doctors.Find(doctor.IdDoctor);
                res2.FirstName = doctor.FirstName;
                res2.LastName = doctor.LastName;
                res2.Email = doctor.Email;
                _context.SaveChanges();
                
                return "Succesfully updated!";

            }
            else
            {
                
                throw new Exception("There is no such doctor!");
            }
        }
        //tut8_endpoint?
        public IQueryable getPrescription()
        {
            var pres = _context.Prescription.Select(p => new PrescriptionRe
            {
                IdDoctor = p.IdDoctor,

                IdPatient = p.IdPatient,

                IdPrescription = p.IdPresciption,

               
            }).AsEnumerable();

            return (IQueryable)pres;



        }
    }
}