﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Tutoriol_8.Middleware
{
    public class ErrorLoggingMiddleware
    {
        private readonly RequestDelegate _next;

        public ErrorLoggingMiddleware(RequestDelegate next)
        {
            _next = next;
        }

        public async Task Invoke(HttpContext httpContext)
        {
           
            try
            {
                await _next(httpContext);
            }
            catch (Exception exc)
            {
                httpContext.Response.StatusCode = 500;
                await httpContext.Response.WriteAsync("Unexpected problem!");
            }
        }
    }
}
